const fs = require('fs');
console.log('asd');
console.log(process.argv);